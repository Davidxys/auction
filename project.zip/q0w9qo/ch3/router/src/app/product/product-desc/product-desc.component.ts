import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-product-desc',
  templateUrl: './product-desc.component.html',
  styleUrls: ['./product-desc.component.css']
})
export class ProductDescComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
