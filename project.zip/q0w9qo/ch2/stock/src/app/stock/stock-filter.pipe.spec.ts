import { StockFilterPipe } from './stock-filter.pipe';

describe('StockFilterPipe', () => {
  it('create an instance', () => {
    const pipe = new StockFilterPipe();
    expect(pipe).toBeTruthy();
  });
});
