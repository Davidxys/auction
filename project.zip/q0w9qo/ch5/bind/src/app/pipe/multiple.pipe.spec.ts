/* tslint:disable:no-unused-variable */

import { TestBed, async } from '@angular/core/testing';
import { MultiplePipe } from './multiple.pipe';

describe('MultiplePipe', () => {
  it('create an instance', () => {
    const pipe = new MultiplePipe();
    expect(pipe).toBeTruthy();
  });
});
